package Assignment;

public class HrDep extends SuperDep{
	private String nameH;
	private String workDayH;
	private String workDeadlineH;
	private String activityH;
	
	
	
	
	public HrDep(String nameH, String workDayH,
			String workDeadlineH, String activityH, String holiday) {
		super(nameH, workDayH, workDeadlineH, holiday);
		this.nameH = nameH;
		this.workDayH = workDayH;
		this.workDeadlineH = workDeadlineH;
		this.activityH = activityH;
	}
	public String getNameH() {
		return nameH;
	}
	public void setNameH(String nameH) {
		this.nameH = nameH;
	}
	public String getWorkDayH() {
		return workDayH;
	}
	public void setWorkDayH(String workDayH) {
		this.workDayH = workDayH;
	}
	public String getWorkDeadlineH() {
		return workDeadlineH;
	}
	public void setWorkDeadlineH(String workDeadlineH) {
		this.workDeadlineH = workDeadlineH;
	}
	public String getActivityH() {
		return activityH;
	}
	public void setActivityH(String activityH) {
		this.activityH = activityH;
	}
	
	
	
	
	
	
	
	
	
	
	
}
