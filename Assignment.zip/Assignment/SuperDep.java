package Assignment;

public class SuperDep {
	private String name;
	private String workDay;
	private String workDeadline;
	private String holiday;
	
	
	
	public SuperDep(String name, String workDay, String workDeadline, String holiday) {
		this.name = name;
		this.workDay = workDay;
		this.workDeadline = workDeadline;
		this.holiday = holiday;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWorkDay() {
		return workDay;
	}
	public void setWorkDay(String workDay) {
		this.workDay = workDay;
	}
	public String getWorkDeadline() {
		return workDeadline;
	}
	public void setWorkDeadline(String workDeadline) {
		this.workDeadline = workDeadline;
	}
	public String getHoliday() {
		return holiday;
	}
	public void setHoliday(String holiday) {
		this.holiday = holiday;
	}
	
	
}
