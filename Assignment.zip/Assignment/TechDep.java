package Assignment;

public class TechDep extends SuperDep{
	private String nameT;
	private String workDayT;
	private String workDeadlineT;
	private String infoT;
	
	
	
	
	public TechDep(String nameT, String workDayT,
			String workDeadlineT, String infoT, String holiday) {
		super(nameT, workDayT, workDeadlineT, holiday);
		this.nameT = nameT;
		this.workDayT = workDayT;
		this.workDeadlineT = workDeadlineT;
		this.infoT = infoT;
	}
	public String getNameT() {
		return nameT;
	}
	public void setNameT(String nameT) {
		this.nameT = nameT;
	}
	public String getWorkDayT() {
		return workDayT;
	}
	public void setWorkDayT(String workDayT) {
		this.workDayT = workDayT;
	}
	public String getWorkDeadlineT() {
		return workDeadlineT;
	}
	public void setWorkDeadlineT(String workDeadlineT) {
		this.workDeadlineT = workDeadlineT;
	}
	public String getInfoT() {
		return infoT;
	}
	public void setInfoT(String infoT) {
		this.infoT = infoT;
	}
	
	
	
	
	

	
	
	
	
	
	
	
	
	
}
