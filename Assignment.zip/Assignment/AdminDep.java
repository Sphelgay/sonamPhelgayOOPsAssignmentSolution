package Assignment;

public class AdminDep extends SuperDep{
	private String nameA;
	private String workDayA;
	private String workDeadlineA;
	
	
	
	public AdminDep(String nameA, String workDayA,
			String workDeadlineA, String holiday) {
		super(nameA, workDayA, workDeadlineA, holiday);
		this.nameA = nameA;
		this.workDayA = workDayA;
		this.workDeadlineA = workDeadlineA;
	}
	public String getNameA() {
		return nameA;
	}
	public void setNameA(String nameA) {
		this.nameA = nameA;
	}
	public String getWorkDayA() {
		return workDayA;
	}
	public void setWorkDayA(String workDayA) {
		this.workDayA = workDayA;
	}
	public String getWorkDeadlineA() {
		return workDeadlineA;
	}
	public void setWorkDeadlineA(String workDeadlineA) {
		this.workDeadlineA = workDeadlineA;
	}
	
	
	
}
