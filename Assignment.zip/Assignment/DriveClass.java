package Assignment;

public class DriveClass {

	public static void main(String[] args) {
		
		String a = "Today is not a holiday";
		String b = "Complete by EOD";
		AdminDep admindep = new AdminDep("welcome to Admin Department", "Complete your documents submission",b , a);
		HrDep hrdep = new HrDep("welcome to HR Department", "Fill today's timesheet and mark your attendance", b, "Team lunch", a);
		TechDep techdep = new TechDep("welcome to Tech Department", "Complete coding of Module 1", b, "Core Java", a);

		System.out.println(admindep.getNameA() + "\n" + admindep.getWorkDayA() + "\n" + admindep.getWorkDeadlineA() + "\n" + admindep.getHoliday());
		System.out.println();
		System.out.println(hrdep.getNameH() + "\n" + hrdep.getActivityH() + "\n" + hrdep.getWorkDayH() + "\n" + hrdep.getWorkDeadlineH() + "\n" + hrdep.getHoliday());
		System.out.println();
		System.out.println(techdep.getNameT() + "\n" + techdep.getWorkDayT() + "\n" + techdep.getWorkDeadlineT() + "\n" + techdep.getInfoT() + "\n" + techdep.getHoliday());
	}

}
